-- First, we can create the torso, legs and head.
sanshead = CreateSprite("sans/sanshead")
sanstorso = CreateSprite("sans/sanstorso")
sanslegs = CreateSprite("sans/sanslegs")

--We parent the torso to the legs, so when you move the legs, the torso moves too. 
--We do the same for attaching the head to the torso.
sanshead.SetParent(sanstorso)
sanstorso.SetParent(sanslegs)

--We define the position of the parts
sanshead.y = 0
sanstorso.y = 55
sanslegs.y = 235

--We set the height of the parts
sanshead.SetPivot(0.5, 0)
sanshead.SetAnchor(0.5, 0)
sanstorso.SetPivot(0.5, 0)
sanstorso.SetAnchor(0.5, 0)
sanslegs.SetPivot(0.5, 0)
sanslegs.SetAnchor (0.5, 0)

--This makes the enemy move
function AnimateSans()
    sanslegs.Scale(1, 1 + 0.1*math.sin(Time.time*2))
    sanshead.MoveTo(0*math.sin(Time.time), 95 + 0*math.cos(Time.time))
    sanshead.rotation = 0*math.sin(Time.time + 0)
    sanstorso.rotation = 0*math.sin(Time.time + 0)
end