﻿using UnityEngine;
using System.Collections;

public class Keyframe {
    public Sprite sprite;

    public Keyframe(Sprite sprite)
    {
        this.sprite = sprite;
    }
}
