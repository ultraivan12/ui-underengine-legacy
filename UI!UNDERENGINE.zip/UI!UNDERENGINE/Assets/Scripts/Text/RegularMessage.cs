﻿public class RegularMessage : TextMessage
{
    public RegularMessage(string text)
        : base(text, true, false)
    {
    }
}