﻿using UnityEngine;

public class DestroyOnLoad : MonoBehaviour
{
    // Use this for initialization
    private void Start()
    {
        Destroy(gameObject);
    }
}